package com.example.newtotolist

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
